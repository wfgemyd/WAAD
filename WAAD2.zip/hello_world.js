const express = require('express'); // import express
const bodyParser = require('body-parser'); // for parsing JSON and url-encoded data
const app = express(); // create an express app

app.get('/', function(req, res){ // define a route handler for the default home page
  for(const key in req.query){
    console.log('Key:', key, 'Value:', req.query[key]); // log the key and value of each query parameter
  }
  res.send('Content of GET query string logged in the console.');

});

app.use(bodyParser.json()); // for parsing application/json
app.use(bodyParser.urlencoded({ extended: false })); // for parsing application/x-www-form-urlencoded

app.post('/data', function(req, res){
  const postedData = JSON.stringify(req.body); // transforms the request body object into a JSON string before logging it to the console or including it in the response. 
  console.log('Received POST data: ', postedData);
  res.status(200).send(postedData);
});

app.put('/b', function(req, res){ 
  res.send('put at b');
});

app.delete('/c', function(req, res){
  res.send('delete at c');
});

app.patch('/d', function(req, res){
  res.send('patch d');
});

var server = app.listen(5500, function () {
  var host = server.address().address;
  var port = server.address().port;
  console.log('Example app listening at http://%s:%s', host, port);
});